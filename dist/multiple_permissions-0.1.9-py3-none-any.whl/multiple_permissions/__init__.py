__name__ = "multiple_permissions"
